#!/usr/bin/env python3
import sys
sys.path.append("/python-project-49/brain_games")
sys.path.append("/brain_games")
sys.path.append("/Users/gordeymartin/project-49/python-project-49/brain_games/cli.py")
from brain_games import cli

def main():
    cli.welcome_user()


if __name__ == '__main__':
    main()
