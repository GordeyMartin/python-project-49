### Hexlet tests and linter status:
[![Actions Status](https://github.com/GordeyMartin/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/GordeyMartin/python-project-49/actions)

<a href="https://codeclimate.com/github/GordeyMartin/python-project-49/maintainability"><img 
src="https://api.codeclimate.com/v1/badges/4df5e11a7fc86d141667/maintainability" /></a>

https://asciinema.org/a/609941

https://asciinema.org/a/q0wNHhlGbgljDnKeyHBJkQzx3
